# بناء تطبيق فواتير باقاتي إلى APK من GitHub

1. أنشئ مستودعًا جديدًا على GitHub.
2. ارفع محتويات هذا المجلد إلى المستودع (لا ترفع ملف ZIP نفسه فقط).
3. افتح تبويب Actions.
4. اختر Build BaqatyInvoices APK ثم Run workflow.
5. بعد انتهاء البناء افتح نتيجة التشغيل ونزّل Artifact باسم BaqatyInvoices-debug-apk.
6. فك ضغط Artifact وثبّت app-debug.apk على هاتف Android.

يتطلب ذلك اتصال إنترنت وحساب GitHub. ملف APK الناتج نسخة Debug للتجربة والتثبيت الشخصي.
