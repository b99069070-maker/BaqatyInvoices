package com.boda.baqaty;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.util.*;

public class Db extends SQLiteOpenHelper {
    public Db(Context c) { super(c, "baqaty.db", null, 1); }
    @Override public void onCreate(SQLiteDatabase d) {
        d.execSQL("CREATE TABLE packages(id INTEGER PRIMARY KEY AUTOINCREMENT, operator TEXT, title TEXT, cost REAL, price REAL)");
        d.execSQL("CREATE TABLE invoices(id INTEGER PRIMARY KEY AUTOINCREMENT, customer TEXT, phone TEXT, operator TEXT, package_title TEXT, qty INTEGER, cost REAL, price REAL, total REAL, profit REAL, created_at TEXT)");
    }
    @Override public void onUpgrade(SQLiteDatabase d,int o,int n) {}
    public void addPackage(String op,String title,double cost,double price) {
        ContentValues v=new ContentValues(); v.put("operator",op); v.put("title",title); v.put("cost",cost); v.put("price",price);
        getWritableDatabase().insert("packages",null,v);
    }
    public List<Pack> packages() {
        List<Pack> a=new ArrayList<>();
        try(Cursor c=getReadableDatabase().rawQuery("SELECT id,operator,title,cost,price FROM packages ORDER BY operator,title",null)) {
            while(c.moveToNext()) a.add(new Pack(c.getLong(0),c.getString(1),c.getString(2),c.getDouble(3),c.getDouble(4)));
        } return a;
    }
    public long saveInvoice(String customer,String phone,Pack p,int qty,String date) {
        double total=p.price*qty, profit=(p.price-p.cost)*qty;
        ContentValues v=new ContentValues(); v.put("customer",customer); v.put("phone",phone); v.put("operator",p.operator);
        v.put("package_title",p.title); v.put("qty",qty); v.put("cost",p.cost); v.put("price",p.price);
        v.put("total",total); v.put("profit",profit); v.put("created_at",date);
        return getWritableDatabase().insert("invoices",null,v);
    }
    public Cursor history() {
        return getReadableDatabase().rawQuery("SELECT id,customer,phone,operator,package_title,qty,total,profit,created_at FROM invoices ORDER BY id DESC",null);
    }
    public double[] totals() {
        double[] x=new double[2];
        try(Cursor c=getReadableDatabase().rawQuery("SELECT COALESCE(SUM(total),0),COALESCE(SUM(profit),0) FROM invoices",null)) {
            if(c.moveToFirst()){x[0]=c.getDouble(0);x[1]=c.getDouble(1);}
        } return x;
    }
    public static class Pack {
        public long id; public String operator,title; public double cost,price;
        public Pack(long i,String o,String t,double c,double p){id=i;operator=o;title=t;cost=c;price=p;}
        @Override public String toString(){return operator+" - "+title+" (بيع "+price+" ج)";}
    }
}
