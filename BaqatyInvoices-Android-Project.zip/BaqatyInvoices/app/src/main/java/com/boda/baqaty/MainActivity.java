package com.boda.baqaty;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.database.Cursor;
import android.graphics.*;
import android.print.*;
import android.view.*;
import android.webkit.WebView;
import android.widget.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    Db db; LinearLayout base; Spinner packagesSpinner; EditText customer,phone,qty; TextView total,stats;
    ArrayList<Db.Pack> packs=new ArrayList<>(); final String[] operators={"اتصالات","فودافون","أورنج","WE"};
    int teal=Color.rgb(7,91,101), dark=Color.rgb(25,39,52);
    @Override public void onCreate(Bundle b){super.onCreate(b); db=new Db(this); showHome();}
    int dp(float n){return (int)(n*getResources().getDisplayMetrics().density+.5f);}
    TextView text(String s,int size,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(dark);if(bold)t.setTypeface(null,1);t.setPadding(0,dp(6),0,dp(6));return t;}
    LinearLayout column(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);l.setPadding(dp(18),dp(12),dp(18),dp(18));return l;}
    void init(String title){base=column();base.setBackgroundColor(Color.rgb(245,247,250)); ScrollView sc=new ScrollView(this);sc.addView(base);setContentView(sc);
        TextView h=text(title,24,true);h.setTextColor(teal);base.addView(h);}
    Button btn(String s,Runnable r){Button b=new Button(this);b.setText(s);b.setAllCaps(false);b.setOnClickListener(v->r.run());return b;}
    EditText edit(String hint,int input){EditText e=new EditText(this);e.setHint(hint);e.setTextSize(16);e.setInputType(input);base.addView(e);return e;}
    void showHome(){
        init("فواتير باقاتي");
        double[] t=db.totals();
        TextView welcome=text("إدارة مبيعات الباقات وكروت الشحن",16,false);base.addView(welcome);
        stats=text("إجمالي المبيعات: "+money(t[0])+" ج\nإجمالي الربح: "+money(t[1])+" ج",18,true);stats.setPadding(0,dp(18),0,dp(18));base.addView(stats);
        base.addView(btn("＋ فاتورة جديدة",this::showInvoice));
        base.addView(btn("＋ إضافة باقة / تعديل الأسعار",this::addPackageDialog));
        base.addView(btn("سجل الفواتير",this::showHistory));
        base.addView(text("ملاحظة: أضف باقاتك وأسعار التكلفة والبيع أولاً. البيانات محفوظة على الجهاز.",13,false));
    }
    void showInvoice(){
        init("فاتورة بيع جديدة");
        customer=edit("اسم العميل (اختياري)", android.text.InputType.TYPE_CLASS_TEXT);
        phone=edit("رقم الموبايل (اختياري)",android.text.InputType.TYPE_CLASS_PHONE);
        base.addView(text("اختر الباقة",16,true));
        packs=new ArrayList<>(db.packages()); packagesSpinner=new Spinner(this);
        ArrayAdapter<Db.Pack> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,packs);
        packagesSpinner.setAdapter(ad);base.addView(packagesSpinner);
        qty=edit("الكمية",android.text.InputType.TYPE_CLASS_NUMBER);qty.setText("1");
        total=text("الإجمالي: —",19,true);base.addView(total);
        packagesSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){
            public void onNothingSelected(android.widget.AdapterView<?> a){total.setText("أضف باقة أولاً");}
            public void onItemSelected(android.widget.AdapterView<?> a,View v,int p,long id){updateTotal();}
        });
        qty.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){updateTotal();}public void afterTextChanged(android.text.Editable e){}});
        base.addView(btn("حفظ الفاتورة",()->save()));
        base.addView(btn("إضافة باقة جديدة",this::addPackageDialog));
        base.addView(btn("رجوع",this::showHome));
        if(packs.isEmpty()) new AlertDialog.Builder(this).setMessage("لا توجد باقات بعد. أضف أول باقة لتبدأ إصدار الفواتير.").setPositiveButton("إضافة باقة",(d,w)->addPackageDialog()).setNegativeButton("لاحقاً",null).show();
    }
    void updateTotal(){
        if(packs==null||packs.isEmpty()||packagesSpinner==null||total==null)return;
        int pos=packagesSpinner.getSelectedItemPosition();if(pos<0||pos>=packs.size())return;
        int q=parseQty();total.setText("الإجمالي: "+money(packs.get(pos).price*q)+" ج");
    }
    int parseQty(){try{return Math.max(1,Integer.parseInt(qty.getText().toString().trim()));}catch(Exception e){return 1;}}
    void save(){
        if(packs.isEmpty()){toast("أضف باقة أولاً");return;}
        Db.Pack p=packs.get(packagesSpinner.getSelectedItemPosition());
        String name=customer.getText().toString().trim(), ph=phone.getText().toString().trim();
        String date=new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date());
        long id=db.saveInvoice(name,ph,p,parseQty(),date);
        if(id>0){new AlertDialog.Builder(this).setTitle("تم حفظ الفاتورة رقم "+id)
            .setMessage("العميل: "+(name.isEmpty()?"—":name)+"\n"+p.operator+" - "+p.title+"\nالكمية: "+parseQty()+"\nالإجمالي: "+money(p.price*parseQty())+" ج\nالربح: "+money((p.price-p.cost)*parseQty())+" ج")
            .setPositiveButton("مشاركة الفاتورة",(d,w)->shareInvoice(id,name,ph,p,parseQty(),date))
            .setNeutralButton("طباعة / PDF",(d,w)->printInvoice(id,name,ph,p,parseQty(),date))
            .setNegativeButton("الصفحة الرئيسية",(d,w)->showHome()).show();}
        else toast("تعذر حفظ الفاتورة");
    }
    void addPackageDialog(){
        LinearLayout form=new LinearLayout(this);form.setPadding(dp(20),dp(8),dp(20),0);form.setOrientation(1);
        Spinner op=new Spinner(this);op.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,operators));form.addView(op);
        EditText title=new EditText(this);title.setHint("اسم الباقة (مثال: 30 جيجا)");form.addView(title);
        EditText cost=new EditText(this);cost.setHint("سعر التكلفة بالجنيه");cost.setInputType(8194);form.addView(cost);
        EditText price=new EditText(this);price.setHint("سعر البيع بالجنيه");price.setInputType(8194);form.addView(price);
        new AlertDialog.Builder(this).setTitle("إضافة باقة").setView(form).setPositiveButton("حفظ",(d,w)->{
            try{String n=title.getText().toString().trim();double c=Double.parseDouble(cost.getText().toString()),p=Double.parseDouble(price.getText().toString());
                if(n.isEmpty()||c<0||p<0)throw new Exception();db.addPackage(op.getSelectedItem().toString(),n,c,p);toast("تمت إضافة الباقة");
                if(packagesSpinner!=null)showInvoice();else showHome();
            }catch(Exception e){toast("راجع اسم الباقة والأسعار");}
        }).setNegativeButton("إلغاء",null).show();
    }
    void showHistory(){
        init("سجل الفواتير");
        Cursor c=db.history();double sales=0,profit=0;int count=0;
        while(c.moveToNext()){
            long id=c.getLong(0);String name=c.getString(1),ph=c.getString(2),op=c.getString(3),pkg=c.getString(4);
            int q=c.getInt(5);double total=c.getDouble(6),pr=c.getDouble(7);String date=c.getString(8);
            TextView row=text("فاتورة #"+id+"  |  "+date+"\n"+op+" - "+pkg+" × "+q+"\n"+(name==null?"":name)+"  "+(ph==null?"":ph)+"\nالإجمالي: "+money(total)+" ج   •   الربح: "+money(pr)+" ج",15,true);
            row.setBackgroundColor(Color.WHITE);row.setPadding(dp(12),dp(10),dp(12),dp(10));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(8);base.addView(row,lp);
            sales+=total;profit+=pr;count++;
        } c.close();
        if(count==0)base.addView(text("لا توجد فواتير محفوظة حتى الآن.",16,false));
        base.addView(text("عدد الفواتير: "+count+"\nالمبيعات: "+money(sales)+" ج\nالأرباح: "+money(profit)+" ج",18,true));
        base.addView(btn("رجوع",this::showHome));
    }
    void shareInvoice(long id,String name,String ph,Db.Pack p,int q,String date){
        String body="فاتورة رقم "+id+"\nالتاريخ: "+date+"\nالعميل: "+name+"\nالهاتف: "+ph+"\nالشبكة: "+p.operator+"\nالباقة: "+p.title+"\nالكمية: "+q+"\nالإجمالي: "+money(p.price*q)+" جنيه";
        Intent i=new Intent(Intent.ACTION_SEND);i.setType("text/plain");i.putExtra(Intent.EXTRA_SUBJECT,"فاتورة بيع رقم "+id);i.putExtra(Intent.EXTRA_TEXT,body);
        startActivity(Intent.createChooser(i,"مشاركة الفاتورة"));
    }

    void printInvoice(long id,String name,String ph,Db.Pack p,int q,String date){
        WebView web=new WebView(this);
        String html="<html><meta charset='utf-8'><body dir='rtl' style='font-family:sans-serif;padding:28px;color:#18333a'>"+
            "<h2 style='text-align:center'>فاتورة بيع باقات</h2><hr>"+
            "<p>رقم الفاتورة: "+id+"</p><p>التاريخ: "+date+"</p><p>العميل: "+(name.isEmpty()?"—":name)+"</p><p>الهاتف: "+(ph.isEmpty()?"—":ph)+"</p>"+
            "<table style='width:100%;border-collapse:collapse' border='1' cellpadding='10'><tr><th>الشبكة</th><th>الباقة</th><th>الكمية</th><th>سعر الوحدة</th><th>الإجمالي</th></tr><tr><td>"+p.operator+"</td><td>"+p.title+"</td><td>"+q+"</td><td>"+money(p.price)+" ج</td><td>"+money(p.price*q)+" ج</td></tr></table>"+
            "<h3>الصافي: "+money(p.price*q)+" جنيه</h3><p style='text-align:center'>شكراً لزيارتكم</p></body></html>";
        web.loadDataWithBaseURL(null,html,"text/HTML","UTF-8",null);
        web.setWebViewClient(new android.webkit.WebViewClient(){
            @Override public void onPageFinished(WebView view,String url){
                PrintManager pm=(PrintManager)getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter adapter=view.createPrintDocumentAdapter("فاتورة-"+id);
                pm.print("فاتورة-"+id,adapter,new PrintAttributes.Builder().setMediaSize(PrintAttributes.MediaSize.ISO_A4).setResolution(new PrintAttributes.Resolution("pdf","PDF",300,300)).setMinMargins(PrintAttributes.Margins.NO_MARGINS).build());
            }
        });
    }
    String money(double v){return String.format(Locale.US,"%.2f",v);}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
